package com.gami.starwars.utils;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.annotation.ColorInt;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CommonUtils {

}
