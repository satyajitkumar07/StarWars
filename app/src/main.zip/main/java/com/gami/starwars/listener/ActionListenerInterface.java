package com.gami.starwars.listener;

public interface ActionListenerInterface {
    void getActionListener(int index);
}
