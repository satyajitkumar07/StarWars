package com.gami.starwars.utils;

public class CommonData {
    public static int backId=16908332;
}
